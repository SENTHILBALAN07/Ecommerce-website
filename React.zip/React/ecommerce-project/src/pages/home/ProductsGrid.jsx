import { Product } from './Product';

export function ProductsGrid({ products, loadCart, searchQuery }) {
  return (
    <div className="products-grid">
      {products.map((product) =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ? (
          <Product key={product.id} product={product} loadCart={loadCart} />
        ) : null
      )}
    </div>
  );
}
