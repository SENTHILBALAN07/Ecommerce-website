import React from 'react'
import './App.css'
import HomePage from './Component/Home/HomePage';
import { Route, Routes } from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';
import Checkout from './Component/Checkout/Checkout';
import { OrdersPage } from './Component/orders/OrdersPage';
const App = () => {
  const [cart, setCart] = useState([]);
  console.log
  useEffect(()=> {
   const car=async()=>{
    const response= await axios.get("http://localhost:3000/api/cart-items?expand=product");
    setCart(response.data);
   }
   car();
  },[]);
  return (
    <Routes>
      <Route element={<HomePage  cart={cart} />} index />
      <Route element={<Checkout cart={cart} />} path='checkout' />
      <Route element={<OrdersPage cart={cart}/>} path='order'/>
    </Routes>

  )
}

export default App
