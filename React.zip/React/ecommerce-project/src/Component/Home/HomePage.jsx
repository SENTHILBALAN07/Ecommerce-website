import {useState, useEffect} from 'react'
import Cartalyst from '../../assets/Cartalyst.png'
import SearchIcon from '../../assets/icons/search-icon.png'
import CartIcon from '../../assets/icons/cart-icon.png'
import { Link } from 'react-router-dom'
import './HomePage.css'
import axios from 'axios'
import format from '../../utils/Money'
const HomePage = ({cart}) => {
  const [products,setProduct]=useState([]);
  useEffect(
    ()=>{
      const pro=async()=>{
         const response=await axios.get("/api/products");
        setProduct(response.data)
      }
      pro();
    },
    []
  )
   let Quantity=0;
  cart.forEach((element)=>Quantity+=element.quantity)
  return (
    <>
      <div className='NavBar'>
      <div className='NavLeft'>
          <img src={Cartalyst} className='Cartalyst' alt="logo of image" />
      </div>
      <div className='NavMiddle '>
        <input type="text" placeholder='Search' className='SearchBar' />
        <button className='SearchIcon'>
          <img src={SearchIcon} alt="Search button" />
        </button>
      </div>
      <div className='NavRight'>
        <Link to="/order"><h3 className='Order'>orders</h3></Link>
         <Link to="/checkout" className='CartWrapper'>
          <img src={CartIcon} alt="icon of card" className='CartIcon'/>
          <p>{Quantity}</p>
         </Link>
         
      </div>
    </div>
   
      
      <div className='Body' >
        {products.map((elements) => (
          <div className='Element' key={elements.id}>
            <img
              src={elements.image}
              alt={elements.name.toLowerCase()}
              width={200}
              className='image'
            />
            <div className='Details'>
              <p className='name'>{elements.name}</p>
              <div className='Ratings'>
                <div>
                  <img src={`images/ratings/rating-${(elements.rating.stars) * 10}.png`} alt="rating" />
                </div>
                <div><p>{(elements.rating.count)}</p></div>
              </div>
              <div className='Pricing'>
                <p>{format(elements.priceCents)}</p>
              </div>
              <div className='End'>
                <div>
                  <select name="quantity" id="quantity">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                  </select>

                </div>
                <div><button 
                  onClick={
                    axios.delete('/api/cart-items',
                      {productId:elements.id,
                        quantity:elements.quantity
                      }
                    )
                    
                  }
                >Add to cart</button></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  )
}

export default HomePage

