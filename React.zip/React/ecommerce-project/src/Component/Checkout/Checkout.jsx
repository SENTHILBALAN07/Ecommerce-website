import Cartalyst from '../../assets/Cartalyst.png';
import './Checkout.css';
import CheckoutLock from '../../assets/icons/checkout-lock-icon.png';
import { Link } from 'react-router-dom';
import format from '../../utils/Money';
import { useEffect, useState } from 'react';
import axios from 'axios';
import dayjs from 'dayjs';

const Checkout = ({ cart }) => {
  const [deliveryOption, setDeliveryOption] = useState([]);
  const [paymentDetails, setPaymentDetails] = useState(null);
  useEffect(() => {
    const deliveryOption= async ()=>{
      const response=await axios.get('/api/delivery-options?expand=estimatedDeliveryTime');
      setDeliveryOption(response.data);
    }
    deliveryOption();
    },[]);

  useEffect(() => {
    const Payment= async ()=>{
      const response=await axios.get('/api/payment-summary');
      setPaymentDetails(response.data);
    }
    Payment();
  }, []);

  return (
    <div className="CBody">
      <nav>
        <div className="CNavBar">
          <div className="CNavLeft">
            <Link to="/" className="HeaderLink">
              <img src={Cartalyst} className="Cartalyst" alt="logo" />
            </Link>
          </div>
          <div className="CNavMiddle">
            <p>
              Checkout({cart.length} item{cart.length > 1 ? 's' : ''})
            </p>
          </div>
          <div className="CNavRight">
            <img src={CheckoutLock} alt="CheckoutLock logo" className="Lock" />
          </div>
        </div>
      </nav>

      <div className="Combinator">
        <div className="ProductsColumn">
          {deliveryOption.length > 0 &&
            cart.map((element) => {
              const DeliveryDate = deliveryOption.find(
                (option) => option.id === element.deliveryOptionId
              );

              return (
                <div className="CartList" key={element.id}>
                  <div className="ProductDelivery">
                    <div className="Product">
                      <img
                        src={element.product.image}
                        alt={element.product.name}
                      />
                      <div className="ProductDetails">
                        <p>
                          <b>{element.product.name}</b>
                        </p>
                        <p>
                          <b>Price: {format(element.product.priceCents)}</b>
                        </p>
                        <p>Quantity: {element.quantity}</p>
                        <div className="ProductButtons">
                          <button className="UpdateBtn">Update</button>
                          <button className="DeleteBtn">Delete</button>
                        </div>
                      </div>
                    </div>

                    <div className="DeliveryDate">
                      <p>
                        <b>Choose delivery option:</b>
                      </p>
                      {deliveryOption.map((option) => {
                        let price = 'FREE Shipping';
                        if (option.priceCents > 0) {
                          price = format(option.priceCents);
                        }
                        return (
                          <label className="radio-inline" key={option.id}>
                            <input
                              type="radio"
                              checked={option.id === element.deliveryOptionId}
                              name={`deliveryOption-${element.productId}`}
                              className="DeliveryOption"
                              readOnly
                            />
                            <div className="sub">
                              <span>
                                {dayjs(option.estimatedDeliveryTimeMs).format(
                                  'dddd, MMMM D'
                                )}
                              </span>
                              <br />
                              <span>{price}</span>
                            </div>
                          </label>
                        );
                      })}
                    </div>

                    {DeliveryDate && (
                      <div className="Date">
                        <p>
                          Delivery Date:{' '}
                          {dayjs(DeliveryDate.estimatedDeliveryTimeMs).format(
                            'dddd, MMMM D'
                          )}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
        </div>

        <div className="Payment">
          <h4>Payment summary</h4>

          {!paymentDetails ? (
            <p>Loading payment details...</p>
          ) : (
            <>
              <div className="PaymentRow">
                <span>Items ({paymentDetails.totalItems}):</span>
                <span>{format(paymentDetails.productCostCents)}</span>
              </div>

              <div className="PaymentRow">
                <span>Shipping & handling:</span>
                <span>{format(paymentDetails.shippingCostCents)}</span>
              </div>

              <div className="PaymentRow">
                <span>Total before tax:</span>
                <span>{format(paymentDetails.totalCostBeforeTaxCents)}</span>
              </div>

              <div className="PaymentRow">
                <span>Estimated tax(10%):</span>
                <span>{format((paymentDetails.taxCents))}</span>
              </div>

              <hr />

              <div className="PaymentRow Total">
                <b>Order total:</b>
                <b>{format(paymentDetails.totalCostCents)}</b>
              </div>

              <button className="CheckoutBtn">Proceed to Checkout</button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Checkout;

