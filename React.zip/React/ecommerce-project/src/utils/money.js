export function formatMoney(amountCents) {
   return `${Number((amountCents/100)*30).toFixed(2)}₹`;
}