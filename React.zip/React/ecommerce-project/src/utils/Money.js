function format(amount) {
  return `${Number((amount/100)*50).toFixed(2)}₹`;
}
export default format