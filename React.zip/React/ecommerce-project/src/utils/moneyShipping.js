export function moneyShipping(amountCents) {
   return `${Number((amountCents/100)*20).toFixed(2)}₹`;
}